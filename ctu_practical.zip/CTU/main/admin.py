from django.contrib import admin
from main.models import Patient, Study
# Register your models here.
admin.site.register(Patient)
admin.site.register(Study)
