from django.db import models

# Create your models here.

class Study(models.Model):
    name = models.CharField(max_length=200)
    startDate = models.DateField()
    
    def __unicode__(self):  #For Python 2, use __str__ on Python 3
        return self.name
    
class Patient(models.Model):
    firstName = models.CharField(max_length=200)
    lastName = models.CharField(max_length=200)
    study = models.ForeignKey(Study)
    
    def __unicode__(self):  #For Python 2, use __str__ on Python 3
        return self.firstName + self.lastName