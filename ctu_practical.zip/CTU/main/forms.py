from django import forms
from django.utils import timezone

from main.models import Study


class StudyForm(forms.ModelForm):
    name = forms.CharField(max_length=200, help_text="Please enter the study name.")
    startDate = forms.DateField(initial=timezone.now())

    # An inline class to provide additional information on the form.
    class Meta:
        # Provide an association between the ModelForm and a model
        model = Study
        fields = ('name','startDate')