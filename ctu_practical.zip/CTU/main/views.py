from django.core.urlresolvers import reverse
from django.http import HttpResponse
from django.http.response import HttpResponseRedirect
from django.shortcuts import render

from main.forms import StudyForm
from main.models import Study, Patient


def index(request):

    teacher = 'Filippo'
    study_list = Study.objects.all()
    context_dict = {'boldmessage': "%s taught me how to inject dynamic content in templates!" % teacher , 'studies':study_list}
    return render(request, 'main/index.html', context_dict)

def study(request, studyID):
    
    results = {}
    
    try:
        study = Study.objects.get(pk=studyID)
        patients = Patient.objects.filter(study=study)
        
        results['studyName'] = study.name
        results['patients'] = patients
        results['study'] = study
        
        
    except Study.DoesNotExist:
        pass
    
    return render(request, 'main/study.html', results)


def add_study(request):
    # A HTTP POST?
    if request.method == 'POST':
        form = StudyForm(request.POST)

        # Have we been provided with a valid form?
        if form.is_valid():
            # Save the new study to the database.
            form.save(commit=True)

            # Now call the index() view.
            # The user will be shown the homepage.
            return HttpResponseRedirect(reverse('index'))
        else:
            # The supplied form contained errors - just print them to the terminal.
            print form.errors
    else:
        # If the request was not a POST, display the form to enter details.
        form = StudyForm()

    # Bad form (or form details), no form supplied...
    # Render the form with error messages (if any).
    return render(request, 'main/add_study.html', {'form': form})
    