from django.conf.urls import patterns, url
from main import views

urlpatterns = patterns('',
        url(r'^$', views.index, name='index'),
        url(r'^add_study/$', views.add_study, name='add_study'), # NEW MAPPING!
        url(r'^study/(?P<studyID>\d+)/$', views.study, name='study'),)